# 🚀 0-to-100 DEPLOYMENT GUIDE FOR AURA AESTHETIC SPA & SANCTUARY

Congratulations on acquiring your custom Awwwards-level 3D interactive website from LeadFlow.AI!
Here is how to deploy your site to your custom domain (`auraaestheticspasanctuary.com`) in under 2 minutes:

## Option A: Instant Free Cloud Hosting (Vercel / Cloudflare Pages / Netlify)
1. Install Vercel CLI: `npm i -g vercel`
2. Open terminal in this unzipped folder and run: `vercel --prod`
3. Link your custom domain `auraaestheticspasanctuary.com` in your Vercel project settings!

## Option B: Traditional cPanel / DirectAdmin / WordPress Hosting
1. Log into your web hosting cPanel and open **File Manager**.
2. Navigate to the `public_html` (or www) directory.
3. Upload the `index.html` file from this package into `public_html`.
4. Your website is instantly live at `https://auraaestheticspasanctuary.com` with SSL!

## Option C: Docker Cloud VPS (AWS / Render / DigitalOcean / Hetzner)
1. In this folder, run: `docker build -t aura_aesthetic_spa___sanctuary-site .`
2. Run container: `docker run -d -p 80:80 aura_aesthetic_spa___sanctuary-site`

Need automated DNS configuration assistance? Reply to your LeadFlow Concierge!